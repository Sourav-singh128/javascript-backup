//let n=window.prompt("enter no.")
let n=5
let str=""
for (let i =0; i<n; i++) {
  for (let j = 0; j < n; j++) {
    str +="*"
  }
  str+="\n"
}
console.log(str)
