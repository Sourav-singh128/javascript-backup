let arr=[1,2,3,4,5,6,7,7,8,9,9]

console.log(arr.slice(-2))

const unique= [...new Set(arr)]
console.log(unique)
