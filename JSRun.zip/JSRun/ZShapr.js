let z=""
for (let i = 1; i <6; i++) {
  for (let j = 1; j < 6; j++) {
    if(i==1 || i==5)
    z+=j
    else if(j==6-i) 
    z+=6-
    else 
    z+=" "
  }
  z+="\n"
}
console.log(z)