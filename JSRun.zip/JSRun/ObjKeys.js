let car={
  name:"ford",
  color:"black",
  model:"Avenger"
}

for(let key of Object.keys(car)){
  console.log(key,car[key])
}