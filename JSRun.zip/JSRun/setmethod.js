const arr=[1,2,2,3,3,4,5]

const arra=[...new Set(arr)]

console.log(arra)

const str="mom"
const myset=[...new Set(str)].join('')
console.log(myset)