let c={greeting:'hey'}
let d
d=c
c.greeting="hello"
console.log(d.greeting)

function bark(){
  console.log('hi')
}
bark.animal="dog"
 bark()
 
 
 const obj={
   a:'one',
   b:'two',
   a:'three'
 }
 
 console.log(obj,"obj")
 
 
 
 console.log("_________Reverse String_______")
 
 str="nani"
 let revStr=""
 for(let i=str.length-1;i>=0;i--){
   revStr+=str[i]
 }
 console.log(revStr)
 
 function sayhi(){
name="pramod"
let age=31
  console.log(name)
  console.log(age)
  var name
  
}
sayhi()